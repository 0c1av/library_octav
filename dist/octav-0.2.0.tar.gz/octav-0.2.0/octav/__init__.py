from .color import red, green, yellow, blue, magenta, cyan
