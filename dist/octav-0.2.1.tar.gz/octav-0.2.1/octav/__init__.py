from .color import red, green, yellow, blue, magenta, cyan
from .style import bold, italic, underline, blink, invert, strikethrough